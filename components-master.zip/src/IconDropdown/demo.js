import React from 'react'
import It from './'

const options = [
  {
    id: 'en',
    label: 'English',
    icon:
      'https://upload.wikimedia.org/wikipedia/commons/a/a4/Flag_of_the_United_States.svg',
  },
  {
    id: 'es',
    label: 'Spanish',
    icon:
      'https://upload.wikimedia.org/wikipedia/commons/9/9a/Flag_of_Spain.svg',
  },
  {
    id: 'fr',
    label: 'French',
    icon:
      'https://upload.wikimedia.org/wikipedia/commons/c/c3/Flag_of_France.svg',
  },
  {
    id: 'de',
    label: 'German',
    icon:
      'https://upload.wikimedia.org/wikipedia/commons/b/ba/Flag_of_Germany.svg',
  },
  {
    id: 'it',
    label: 'Italian',
    icon:
      'https://upload.wikimedia.org/wikipedia/commons/0/03/Flag_of_Italy.svg',
  },
  {
    id: 'pt',
    label: 'Portuguese',
    icon:
      'https://upload.wikimedia.org/wikipedia/commons/5/5c/Flag_of_Portugal.svg',
  },
  {
    id: 'sv',
    label: 'Swedish',
    icon:
      'https://upload.wikimedia.org/wikipedia/commons/4/4c/Flag_of_Sweden.svg',
  },
  {
    id: 'fa',
    label: 'Farsi',
    icon: 'https://upload.wikimedia.org/wikipedia/commons/a/a2/Farsi.svg',
  },
  {
    id: 'fa-AF',
    label: 'Dari',
    icon:
      'https://upload.wikimedia.org/wikipedia/commons/0/05/ANP_Flag_Dari.svg',
  },
  {
    id: 'so',
    label: 'Somali',
    icon:
      'https://upload.wikimedia.org/wikipedia/commons/a/a0/Flag_of_Somalia.svg',
  },
  {
    id: 'ti',
    label: 'Tigrinya',
    icon:
      'https://upload.wikimedia.org/wikipedia/commons/5/5d/Flag_of_the_Tigray_Region.svg',
  },
]

class Container extends React.Component {
  constructor({selected}) {
    super()
    this.state = {selected: selected || 'en'}
  }

  render() {
    return (
      <div style={{width: '200px', margin: '0 auto'}}>
        <It
          label="I speak:"
          selectedId={this.state.selected}
          options={options}
          onSelect={id => {
            this.setState({selected: id})
          }}
        />
      </div>
    )
  }
}

export default {
  name: 'IconDropbox',
  usecases: {
    Default: <Container />,
    'Right-to-left': (
      <span className="fromlang-rtl">
        <Container selected="fa" />
      </span>
    ),
  },
}
