import React from 'react'
import './reset.css'
import './shared.css'
import './index.css'

export default function App({children}) {
  return (
    <div>
      {children}
    </div>
  )
}
