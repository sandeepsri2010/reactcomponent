import './index.css'
import React from 'react';

import App from '../App';
import IconDropdown from '../IconDropdown/demo';

const components = {
  IconDropdown,
}

const list = {
  name: 'List',
  usecases: {
    Default: (
      <ul className="list-of-components">
        {Object.keys(components).map(k =>
          <li key={k}>
            <p>{components[k].name}</p>
            {components[k] &&
              components[k].usecases &&
              Object.keys(components[k].usecases).map(usecaseName =>
                <a
                  key={k + usecaseName}
                  href={`#/${encodeURIComponent(k)}/${encodeURIComponent(
                    usecaseName
                  )}`}
                >
                  {usecaseName}
                </a>
              )}
          </li>
        )}
      </ul>
    ),
  },
}

components[''] = list

function getComponent() {
  const [name, usecase] = window.location.hash
    .slice(2)
    .split('/')
    .map(e => decodeURIComponent(e))
  return components[name].usecases[usecase || 'Default']
}

export default class Demo extends React.Component {
  constructor() {
    super()
    this.state = {component: getComponent()}
    this.listener = window.addEventListener(
      'hashchange',
      () => {
        this.setState({component: getComponent()})
      },
      false
    )
  }

  componentWillUnmount() {
    window.removeEventListener(this.listener)
  }

  render() {
    return (
      <App>
        {this.state.component}
      </App>
    )
  }
}
