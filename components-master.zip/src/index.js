import React from 'react'
import ReactDOM from 'react-dom'
import registerServiceWorker from './registerServiceWorker'
import Demo from './Demo'

const rootEl = document.getElementById('root')
ReactDOM.render(<Demo />, rootEl)

module.hot.accept('./Demo', () => {
  const NextDemo = require('./Demo').default
  ReactDOM.render(<NextDemo />, rootEl)
})

registerServiceWorker()
