# Conventions

## Styling

- Every component should have an associated index.css file.

- Each component should have a root class named same as component, in lower-case and with dashes. For example: `IconDropdown` has the root class `icon-dropdown`

- The index.css file **must not** make rules which could affect other components. The easiest way to achieve this is to use the child selector (>) for all descendant elements.

- JSX is responsible for structure and not visuals. Components *should not* make "look and feel" declarations. Do not name classes things like "blue", "thick", etc. Name them what they are: Headings, sections, etc.

- Whenever possible, use short class names, or when suitable omit them entirely. If something is a big headline such as `<h1>`, there's no need to use a class name `"big-headline"`.

