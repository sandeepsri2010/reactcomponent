for file in "$@"
do
  R=`echo $file | sed "s|\.less|\.css|"`
  echo $R
  lessc "$file" "$R"
done
